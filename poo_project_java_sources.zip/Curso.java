import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

class Curso {
    private String nome;
    private Instrutor instrutor;
    private List<Aula> aulas; // Agregação
    private List<Aluno> alunosMatriculados;
    private int limiteAlunos;

    public Curso(String nome, Instrutor instrutor, int limiteAlunos) {
        this.nome = nome;
        this.instrutor = instrutor;
        this.aulas = new ArrayList<>();
        this.alunosMatriculados = new ArrayList<>();
        this.limiteAlunos = limiteAlunos;
    }

    public String getNome() {
        return nome;
    }

    public Instrutor getInstrutor() {
        return instrutor;
    }

    public void adicionarAula(Aula a) {
        this.aulas.add(a);
    }

    public void listarAulas() {
        System.out.println("\n--- Aulas do Curso: " + nome + " ---");
        for (Aula a : aulas) {
            a.exibirDetalhes("->"); // Demonstração de Polimorfismo por Sobrecarga
        }
    }

    // Regra de Negócio com Tratamento de Exceção
    public void matricularAluno(Aluno aluno) throws CursoLotadoException {
        if (aluno == null) {
            System.out.println("Erro: Aluno não pode ser nulo.");
            return;
        }
        if (alunosMatriculados.size() >= limiteAlunos) {
            // Lançar explicitamente a exceção personalizada
            throw new CursoLotadoException("O curso '" + nome + "' atingiu o limite de " + limiteAlunos + " alunos.");
        }
        if (alunosMatriculados.contains(aluno)) {
            System.out.println("Aluno " + aluno.getNome() + " já está matriculado neste curso.");
            return;
        }
        alunosMatriculados.add(aluno);
        System.out.println("Aluno " + aluno.getNome() + " matriculado com sucesso no curso " + nome + ".");
    }

    public List<Aluno> getAlunosMatriculados() {
        return alunosMatriculados;
    }
}