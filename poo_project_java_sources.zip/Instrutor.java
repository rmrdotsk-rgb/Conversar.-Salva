class Instrutor extends Pessoa implements Autenticavel {
    private String areaEspecialidade;

    public Instrutor(String nome, String email, String senha, String areaEspecialidade) {
        super(nome, email, senha);
        this.areaEspecialidade = areaEspecialidade;
    }

    public String getAreaEspecialidade() {
        return areaEspecialidade;
    }

    // Polimorfismo por Sobrescrita (Runtime)
    @Override
    public void exibirDados() {
        System.out.println("--- Dados do Instrutor ---");
        System.out.println("Nome: " + getNome());
        System.out.println("Especialidade: " + areaEspecialidade);
        System.out.println("Email: " + getEmail());
    }

    // Implementação da Interface Autenticavel
    @Override
    public boolean autenticar(String senha) {
        return getSenha().equals(senha);
    }
}