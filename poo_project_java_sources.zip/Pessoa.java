abstract class Pessoa {
    private String nome;
    private String email;
    private String senha;

    public Pessoa(String nome, String email, String senha) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    // Encapsulamento: Getters e Setters públicos para atributos privados
    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Método abstrato para demonstrar Abstração e Polimorfismo
    public abstract void exibirDados();

    // Método auxiliar para autenticação (usado na interface)
    protected String getSenha() {
        return senha;
    }
}