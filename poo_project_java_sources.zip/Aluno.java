class Aluno extends Pessoa implements Autenticavel {
    private String matricula;

    public Aluno(String nome, String email, String senha, String matricula) {
        super(nome, email, senha);
        this.matricula = matricula;
    }

    public String getMatricula() {
        return matricula;
    }

    // Polimorfismo por Sobrescrita (Runtime)
    @Override
    public void exibirDados() {
        System.out.println("--- Dados do Aluno ---");
        System.out.println("Nome: " + getNome());
        System.out.println("Matrícula: " + matricula);
        System.out.println("Email: " + getEmail());
    }

    // Implementação da Interface Autenticavel
    @Override
    public boolean autenticar(String senha) {
        return getSenha().equals(senha);
    }
}