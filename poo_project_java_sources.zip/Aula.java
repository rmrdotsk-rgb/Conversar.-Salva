class Aula {
    private String titulo;
    private int duracaoMinutos;

    public Aula(String titulo, int duracaoMinutos) {
        this.titulo = titulo;
        this.duracaoMinutos = duracaoMinutos;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getDuracaoMinutos() {
        return duracaoMinutos;
    }

    // Polimorfismo por Sobrecarga (Static)
    public void exibirDetalhes() {
        System.out.println("Aula: " + titulo + " (" + duracaoMinutos + " min)");
    }

    public void exibirDetalhes(String prefixo) {
        System.out.println(prefixo + " " + titulo + " (" + duracaoMinutos + " min)");
    }
}