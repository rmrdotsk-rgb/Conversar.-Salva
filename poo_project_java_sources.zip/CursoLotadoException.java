class CursoLotadoException extends Exception {
    public CursoLotadoException(String message) {
        super(message);
    }
}