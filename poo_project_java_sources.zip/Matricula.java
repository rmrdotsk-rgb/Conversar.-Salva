class Matricula {
    private Aluno aluno;
    private Curso curso;
    private Progresso progresso; // Composição

    public Matricula(Aluno aluno, Curso curso) {
        this.aluno = aluno;
        this.curso = curso;
        // Progresso é criado e gerenciado pela Matricula (Composição)
        this.progresso = new Progresso();
    }

    public Aluno getAluno() {
        return aluno;
    }

    public Curso getCurso() {
        return curso;
    }

    public Progresso getProgresso() {
        return progresso;
    }

    public void exibirDetalhes() {
        System.out.println("\n--- Detalhes da Matrícula ---");
        System.out.println("Aluno: " + aluno.getNome());
        System.out.println("Curso: " + curso.getNome());
        System.out.println("Progresso: " + progresso.getPercentualConcluido() + "%");
    }

    // Classe interna estática para demonstrar Composição
    static class Progresso {
        private int percentualConcluido;

        public Progresso() {
            this.percentualConcluido = 0;
        }

        public int getPercentualConcluido() {
            return percentualConcluido;
        }

        public void setPercentualConcluido(int percentualConcluido) {
            if (percentualConcluido >= 0 && percentualConcluido <= 100) {
                this.percentualConcluido = percentualConcluido;
            }
        }
    }
}