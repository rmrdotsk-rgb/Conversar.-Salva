import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // 1. Criar pelo menos um objeto Aluno e um objeto Instrutor.
        System.out.println("--- 1. Criação de Pessoas ---");
        Aluno aluno1 = new Aluno("José Emerson", "jose.emerson@email.com", "senha123", "01802056");
        Aluno aluno2 = new Aluno("Maria da Silva", "maria.silva@email.com", "senha456", "01802057");
        Instrutor instrutor1 = new Instrutor("Prof. Carlos", "carlos.prof@email.com", "profsenha", "Desenvolvimento Java");

        // 2. Criar pelo menos um Curso e duas ou mais Aula.
        System.out.println("\n--- 2. Criação de Curso e Aulas ---");
        Curso cursoJava = new Curso("POO com Java", instrutor1, 1); // Limite de 1 aluno para forçar a exceção

        Aula aula1 = new Aula("Introdução à POO", 60);
        Aula aula2 = new Aula("Classes e Objetos", 90);
        Aula aula3 = new Aula("Herança e Polimorfismo", 120);

        // 3. Associar (agregar) as aulas ao curso.
        System.out.println("\n--- 3. Agregação de Aulas ---");
        cursoJava.adicionarAula(aula1);
        cursoJava.adicionarAula(aula2);
        cursoJava.adicionarAula(aula3);
        cursoJava.listarAulas();

        // 4. Criar uma matrícula de um Aluno em um Curso.
        System.out.println("\n--- 4. Matrícula e Composição ---");
        try {
            // Matricular o primeiro aluno (sucesso)
            cursoJava.matricularAluno(aluno1);
            Matricula matricula1 = new Matricula(aluno1, cursoJava);
            matricula1.getProgresso().setPercentualConcluido(33);
            matricula1.exibirDetalhes();
        } catch (CursoLotadoException e) {
            System.out.println("ERRO DE MATRÍCULA: " + e.getMessage());
        }

        // 5. Chamar um método que poderá lançar a exceção personalizada e Tratar essa exceção.
        System.out.println("\n--- 5. Tratamento de Exceção Personalizada ---");
        try {
            // Tentar matricular o segundo aluno (falha, pois o limite é 1)
            cursoJava.matricularAluno(aluno2);
        } catch (CursoLotadoException e) {
            // Capturar (try/catch) a exceção e exibir mensagem amigável
            System.out.println("ERRO DE MATRÍCULA (Tratado): " + e.getMessage());
        }

        // 6. Demonstrar polimorfismo na prática.
        System.out.println("\n--- 6. Demonstração de Polimorfismo (Sobrescrita) ---");
        List<Pessoa> listaPessoas = new ArrayList<>();
        listaPessoas.add(aluno1);
        listaPessoas.add(instrutor1);

        for (Pessoa p : listaPessoas) {
            // O método exibirDados() correto (Aluno ou Instrutor) é chamado em tempo de execução
            p.exibirDados();
        }

        // 7. Exibir no console algumas informações da estrutura montada.
        System.out.println("\n--- 7. Informações Finais ---");
        System.out.println("Curso: " + cursoJava.getNome());
        System.out.println("Instrutor: " + cursoJava.getInstrutor().getNome());
        System.out.println("Total de Aulas: " + cursoJava.getInstrutor().getNome());
        System.out.println("Alunos Matriculados: " + cursoJava.getAlunosMatriculados().size());
        for (Aluno a : cursoJava.getAlunosMatriculados()) {
            System.out.println("- " + a.getNome() + " (" + a.getMatricula() + ")");
        }
    }
}