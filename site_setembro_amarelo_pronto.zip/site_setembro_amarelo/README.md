# Site Setembro Amarelo

Um site informativo sobre a campanha de conscientização e prevenção do suicídio, com foco em educação, recursos de ajuda e suporte emocional.

## 📋 Visão Geral

O **Setembro Amarelo** é uma campanha de conscientização sobre a prevenção do suicídio. Este site foi desenvolvido com HTML, CSS e JavaScript puro para fornecer informações acessíveis sobre saúde mental e recursos de ajuda.

### Objetivo

Promover a conscientização sobre saúde mental, reduzir estigma e oferecer orientações práticas para quem está passando por dificuldades ou quer ajudar alguém em risco.

## 📄 Páginas do Site

### 1. **Índice (index.html)**
- **Conteúdo**: Landing page com apresentação da campanha
- **Seções**:
  - Hero section com chamada para ação
  - Estatísticas principais sobre suicídio
  - Call-to-action para explorar mais conteúdo

### 2. **Sobre (sobre.html)**
- **Conteúdo**: Informações sobre a campanha Setembro Amarelo
- **Seções**:
  - Definição e objetivos da campanha
  - Fatos importantes sobre prevenção
  - História e contexto do Setembro Amarelo
  - Box com 4 fatos-chave sobre saúde mental

### 3. **Sinais de Alerta (sinais.html)**
- **Conteúdo**: Indicadores de que alguém pode estar em risco
- **Seções**:
  - Sinais verbais (coisas que a pessoa diz)
  - Sinais comportamentais (mudanças no comportamento)
  - Sinais emocionais (estados psicológicos)
  - Situações de risco (contextos vulneráveis)
  - Box de aviso com instruções de emergência

### 4. **Como Ajudar (como-ajudar.html)**
- **Conteúdo**: Guia prático para apoiar alguém em crise
- **Seções**:
  - 6 passos para ajudar de forma efetiva
  - Coisas que NÃO fazer
  - Números de emergência
  - Dicas de como manter contato e não desistir

### 5. **Recursos (recursos.html)**
- **Conteúdo**: Lista de recursos e linhas de ajuda
- **Seções**:
  - Linhas de emergência (CVV, SAMU, Polícia, etc)
  - Recursos online (chats, portais, CAPS)
  - Quando procurar ajuda
  - Mensagem de esperança

## 🎨 Design e Cores

### Paleta de Cores
- **Amarelo (#ffd700)**: Cor principal, símbolo da esperança
- **Azul Escuro (#1a1a2e)**: Cor de fundo e textos principais
- **Roxo (#667eea)**: Destaques e seções especiais
- **Branco e Cinzas**: Backgrounds e textos secundários

### Tipografia
- **Fonte**: Segoe UI, Tahoma, Geneva, Verdana, sans-serif
- **Tamanhos**: Variados de 0.95rem até 3.5rem para hierarquia visual

### Responsividade
- Design mobile-first
- Breakpoints em 768px e 480px
- Menu hambúrguer em dispositivos móveis
- Grids adaptáveis (auto-fit, minmax)

## 🛠️ Tecnologias

### HTML5
- Estrutura semântica
- Formulários acessíveis
- Meta tags otimizadas

### CSS3
- Flexbox e CSS Grid
- Animações e transições
- Media queries responsivas
- Gradientes lineares

### JavaScript
- Menu mobile interativo
- Detecção de página ativa
- Scroll suave
- Animações ao rolar (Intersection Observer API)
- Sem dependências externas

## 📱 Recursos Interativos

### Menu de Navegação
- Menu sticky no topo
- Botão hambúrguer em mobile
- Links destacam a página atual
- Menu fecha ao clicar em um link

### Animações
- Fade-in na entrada das seções
- Hover effects em botões e cards
- Animação de flutuação na hero
- Efeito de elevação ao passar o mouse (translateY)

### Acessibilidade
- Alt text em imagens
- Cores com bom contraste
- Tamanhos de fonte legíveis
- Estrutura lógica de headings

## 📂 Estrutura de Arquivos

\`\`\`
projeto-setembro-amarelo/
│
├── index.html          # Página inicial
├── sobre.html          # Página sobre a campanha
├── sinais.html         # Página de sinais de alerta
├── como-ajudar.html    # Página de orientações
├── recursos.html       # Página de recursos
├── styles.css          # Estilos compartilhados
├── script.js           # JavaScript funcional
└── README.md           # Este arquivo
\`\`\`

## 🚀 Como Usar

### 1. Baixar o Projeto
- Clique em "Download ZIP" no v0
- Descompacte o arquivo na sua máquina

### 2. Abrir no Navegador
- Abra a pasta do projeto
- Clique em `index.html`
- O site abrirá no seu navegador padrão

### 3. Navegar
- Use o menu de navegação para ir entre as páginas
- Em dispositivos móveis, clique no ícone de menu
- Todos os links internos funcionam perfeitamente

## 📞 Informações Importantes

### Linhas de Emergência Brasil
- **CVV (Centro de Valorização da Vida)**: 188 - Disponível 24h
- **SAMU**: 192 - Ambulância e emergência médica
- **Polícia Militar**: 190 - Para situações de risco
- **Disque Direitos Humanos**: 100 - Denúncias e orientações

## 💡 Dicas de Uso

- **Para educar**: Use o site em escolas e comunidades
- **Para compartilhar**: Compartilhe com redes de apoio
- **Para marcar**: Adicione ao seu navegador nos favoritos
- **Para enviar**: Compartilhe o link em grupos e redes sociais

## 🔍 SEO e Meta Tags

Todas as páginas incluem:
- Meta description otimizada
- Viewport configurada para mobile
- Charset UTF-8
- Títulos informativos

## 📝 Notas Importantes

- O site não substitui atendimento profissional
- Em caso de emergência, ligue para os números fornecidos
- Respeite a privacidade e sensibilidade do assunto
- Sempre recomende buscar ajuda profissional

## 🤝 Contribuir

Este é um projeto de conscientização. Sinta-se livre para:
- Copiar e usar em sua comunidade
- Modificar conforme necessário
- Compartilhar com outras pessoas
- Traduzir para outros idiomas

## 📄 Licença

Projeto de uso livre para fins educacionais e de conscientização sobre saúde mental.

## ❤️ Mensagem Final

**Você não está sozinho. Se você ou alguém que conhece está passando por dificuldades, procure ajuda. Existe esperança.**

---

**Desenvolvido com ❤️ para a conscientização sobre saúde mental**